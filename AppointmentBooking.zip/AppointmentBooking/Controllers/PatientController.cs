﻿using AppointmentBooking.Models;
using AppointmentBooking.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Controllers
{
   // [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class PatientController : ControllerBase
    {
        private readonly IPatientService _patientService;

        public PatientController(IPatientService patientService)
        {
            _patientService = patientService;
        }
        [HttpPost("Register")] // sukesh
        public async Task<IActionResult> RegisterPatient([FromBody] Patient patient
            )
        {
            // return pat

            await _patientService.RegistrPatientAsync(patient);

            return Ok("Registraion successfully.");
        }

        // end sukesh
        [Authorize]
        [HttpPost("BookAppointment")]
        public async Task<IActionResult> BookAppointment([FromBody] Appointment appointment)
        {
            bool isBooked = await _patientService.BookAppointmentAsync(appointment);
            if (!isBooked)
                return BadRequest("Physician is not available or patient already has an appointment at this time.");

            return Ok("Appointment booked successfully.");
        }

        [Authorize]
        [HttpGet("GetAppointments/{patientId}")]
        public async Task<ActionResult<List<Appointment>>> GetAppointments(int patientId)
        {
            var appointments = await _patientService.GetAppointmentsByPatientIdAsync(patientId);
            return Ok(appointments);
        }
        [Authorize]
        [HttpGet("GetMedicalRecord/{appointmentId}")]
        public async Task<ActionResult<MedicalRecord>> GetMedicalRecord(int appointmentId)
        {
            var record = await _patientService.GetMedicalRecordByAppointmentIdAsync(appointmentId);
            if (record == null)
                return Ok(new List<MedicalRecord>());

            return Ok(record);
        }
    }
}
