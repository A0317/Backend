﻿using AppointmentBooking.Models;
using AppointmentBooking.Services;
using AppointmentBooking.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Controllers
{
   // [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentService _appointmentService;

        public AppointmentController(IAppointmentService appointmentService)
        {
            _appointmentService = appointmentService;
        }

        [HttpPost("book")]
        public async Task<IActionResult> BookAppointment([FromBody] Appointment appointment)
        {
            bool isBooked = await _appointmentService.BookAppointmentAsync(appointment);
            if (!isBooked) return BadRequest("Physician or Patient is unavailable at this time.");
            return Ok("Appointment booked successfully!");
        }

        [HttpPut("update-status/{appointmentId}/{status}/{physicianId}")]
        public async Task<IActionResult> ConfirmOrRejectAppointment(int appointmentId, int status, int physicianId)
        {
            bool isUpdated = await _appointmentService.ConfirmOrRejectAppointmentAsync(appointmentId, status, physicianId);
            if (!isUpdated) return BadRequest("Invalid appointment or physician ID.");
            return Ok("Appointment status updated successfully!");
        }
    }
}
