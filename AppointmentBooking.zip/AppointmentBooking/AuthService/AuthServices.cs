﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System;
using AppointmentBooking.Repository.Interface;
using AppointmentBooking.Data;
using System.Linq;

namespace AppointmentBooking.AuthService
{
    public class AuthServices
    {
        private readonly ApplicationDbContext _context;
        private readonly string _secretKey;
        private readonly string _issuer;
        private readonly string _audience;

        public AuthServices(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _secretKey = configuration["Jwt:SecretKey"];
            _issuer = configuration["Jwt:Issuer"];
            _audience = configuration["Jwt:Audience"];
        }

        public (string Token, string Username) Authenticate(string username, string password)
        {
            var admin = _context.Patients.FirstOrDefault(a => a.Email == username && a.PhoneNumber == password);
            var admin1 = _context.Physicians.FirstOrDefault(a => a.Email == username && a.ContactNumber == password);
            if (admin == null && admin1 == null)
            {
                return (null, null);
            }

            var email = admin?.Email ?? admin1?.Email;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_secretKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                        new Claim(ClaimTypes.NameIdentifier, email),
                    // new Claim(ClaimTypes.Role, "Admin")
                }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _issuer,
                Audience = _audience
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return (tokenHandler.WriteToken(token), email);
        }
    }
}
