﻿using AppointmentBooking.Models;
using AppointmentBooking.Repository.Interface;
using AppointmentBooking.Services.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Services
{
    public class PatientService : IPatientService
    {
        private readonly IPatientRepository _patientRepository;

       public PatientService(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }
      
        public async Task<bool> BookAppointmentAsync(Appointment appointment)
        {
            return await _patientRepository.BookAppointmentAsync(appointment);
        }

        public async Task<List<Appointment>> GetAppointmentsByPatientIdAsync(int patientId)
        {
            return await _patientRepository.GetAppointmentsByPatientIdAsync(patientId);
        }

        public async Task<MedicalRecord> GetMedicalRecordByAppointmentIdAsync(int appointmentId)
        {
            return await _patientRepository.GetMedicalRecordByAppointmentIdAsync(appointmentId);
        }

        public async Task<Patient> RegistrPatientAsync(Patient patient)
        {
            return await _patientRepository.RegisterPatientAsync(patient);
        }

        
    }
}
