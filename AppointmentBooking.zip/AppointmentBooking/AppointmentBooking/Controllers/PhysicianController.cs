﻿using AppointmentBooking.Models;
using AppointmentBooking.Repository.Interface;
using AppointmentBooking.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class PhysicianController : ControllerBase
    {
        private readonly IPhysicianService _physicianService;

        public PhysicianController(IPhysicianService physicianService)
        {
            _physicianService = physicianService;
        }
        [Authorize]
        [HttpGet("GetAppointments/{physicianId}")]
        public async Task<ActionResult<List<Appointment>>> GetAppointments(int physicianId)
        {
            var appointments = await _physicianService.GetAppointmentsByPhysicianIdAsync(physicianId);
            return Ok(appointments);
        }
        [Authorize]
        [HttpPut("UpdateAppointmentStatus/{appointmentId}/{status}")]
        public async Task<IActionResult> UpdateAppointmentStatus(int appointmentId, int status)
        {
            bool isUpdated = await _physicianService.UpdateAppointmentStatusAsync(appointmentId, status);
            if (!isUpdated)
                return BadRequest("Invalid appointment ID or status update failed.");

            return Ok("Appointment status updated successfully.");
        }
        [Authorize]
        [HttpPost("AddOrUpdateMedicalRecord")]
        public async Task<IActionResult> AddOrUpdateMedicalRecord([FromBody] MedicalRecord medicalRecord)
        {
            bool isSaved = await _physicianService.AddOrUpdateMedicalRecordAsync(medicalRecord);
            if (!isSaved)
                return BadRequest("Failed to save medical record.");

            return Ok("Medical record saved successfully.");
        }
        [Authorize]
        [HttpGet("GetPhysician")]
        public async Task<ActionResult<List<Physician>>> GetPhysician()
        {
            var physicians = await _physicianService.GetPhysician();
            return Ok(physicians);
        }

        [HttpPost("RegisterPhysician")]
        public async Task<IActionResult> RegisterPhysician([FromBody] Physician physician)
        {
            await _physicianService.RegistrPhysicianAsync(physician);
            return Ok("Physician registered successfully.");
        }
    }
}
