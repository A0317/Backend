﻿using AppointmentBooking.AuthService;
using AppointmentBooking.Data;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AppointmentBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        // GET: api/<AuthController>
        private readonly AuthServices _authService;
        private readonly IJwtService _jwtService;
        private readonly ApplicationDbContext _context;

        public AuthController(AuthServices authService, IJwtService jwtService, ApplicationDbContext context)
        {
            _authService = authService;
            _jwtService = jwtService;
            _context = context;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginModel login)
        {
            var (token, username) = _authService.Authenticate(login.Username, login.Password);
            if (token == null)
            {
                return Unauthorized();
            }
            _jwtService.SetJwtToken(token);
            if (login.IsPhysician)
            {
                var userData = _context.Physicians.FirstOrDefault(t => t.Email == login.Username);
                if (userData == null)
                {
                    return NotFound("User not found");
                }
                return Ok(new { Token = token, Id = userData.UserId, PhysicianName = userData.DoctorName, Email=userData.Email });
            }
            var userPatientData = _context.Patients.FirstOrDefault(t => t.Email == login.Username);
            return Ok(new { Token = token,Id=userPatientData.UserId,  PatientName = userPatientData.PatientName, Email= userPatientData.Email });
        }

    }

    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public bool IsPhysician { get; set; }
    }
}
