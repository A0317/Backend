﻿using AppointmentBooking.Models;
using AppointmentBooking.Services.Interface;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class MedicalRecordController : ControllerBase
    {
        private readonly IMedicalRecordService _medicalRecordService;

        public MedicalRecordController(IMedicalRecordService medicalRecordService)
        {
            _medicalRecordService = medicalRecordService;
        }

        [HttpGet("GetById/{medicalRecordId}")]
        public async Task<ActionResult<MedicalRecord>> GetById(int medicalRecordId)
        {
            var record = await _medicalRecordService.GetMedicalRecordByIdAsync(medicalRecordId);
            if (record == null) return NotFound("Medical record not found.");

            return Ok(record);
        }

        [HttpGet("GetByPatient/{patientId}")]
        public async Task<ActionResult<List<MedicalRecord>>> GetByPatient(int patientId)
        {
            var records = await _medicalRecordService.GetMedicalRecordsByPatientIdAsync(patientId);
            return Ok(records);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Add([FromBody] MedicalRecord medicalRecord)
        {
            bool isAdded = await _medicalRecordService.AddMedicalRecordAsync(medicalRecord);
            if (!isAdded) return BadRequest("Failed to add medical record.");

            return Ok("Medical record added successfully.");
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update([FromBody] MedicalRecord medicalRecord)
        {
            bool isUpdated = await _medicalRecordService.UpdateMedicalRecordAsync(medicalRecord);
            if (!isUpdated) return BadRequest("Failed to update medical record.");

            return Ok("Medical record updated successfully.");
        }

        [HttpDelete("Delete/{medicalRecordId}")]
        public async Task<IActionResult> Delete(int medicalRecordId)
        {
            bool isDeleted = await _medicalRecordService.DeleteMedicalRecordAsync(medicalRecordId);
            if (!isDeleted) return BadRequest("Failed to delete medical record.");

            return Ok("Medical record deleted successfully.");
        }
    }
}

