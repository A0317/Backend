﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppointmentBooking.Models
{
    public class Physician
    {
        [Key]
        public int UserId { get; set; } // Primary Key

        [Required]
        public string DoctorName { get; set; }

        [Required]
        public string Specialty { get; set; }

        [Required]
        public string ContactNumber { get; set; }

        [Required]
        public string Email { get; set; }
    }
}
