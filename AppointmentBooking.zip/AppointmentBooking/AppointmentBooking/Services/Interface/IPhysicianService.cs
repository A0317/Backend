﻿using AppointmentBooking.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Services.Interface
{
    public interface IPhysicianService
    {
        Task<List<Appointment>> GetAppointmentsByPhysicianIdAsync(int physicianId);
        // get all physician 
        Task<List<Physician>> GetPhysician();
        //  Register physicians 
        Task<Physician> RegistrPhysicianAsync(Physician patient);
        Task<bool> UpdateAppointmentStatusAsync(int appointmentId, int status);
        Task<bool> AddOrUpdateMedicalRecordAsync(MedicalRecord medicalRecord);
    }
}
