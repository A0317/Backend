﻿using AppointmentBooking.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Services.Interface
{
    public interface IPatientService
    {
        Task<bool> BookAppointmentAsync(Appointment appointment);
        Task<Patient> RegistrPatientAsync(Patient patient);
        Task<List<Appointment>> GetAppointmentsByPatientIdAsync(int patientId);
        Task<MedicalRecord> GetMedicalRecordByAppointmentIdAsync(int appointmentId);
    }
}
