﻿using AppointmentBooking.Models;
using AppointmentBooking.Repository.Interface;
using AppointmentBooking.Services.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AppointmentBooking.Services
{
    public class PhysicianService : IPhysicianService
    {
        private readonly IPhysicianRepository _physicianRepository;

        public PhysicianService(IPhysicianRepository physicianRepository)
        {
            _physicianRepository = physicianRepository;
        }

        public async Task<List<Appointment>> GetAppointmentsByPhysicianIdAsync(int physicianId)
        {
            return await _physicianRepository.GetAppointmentsByPhysicianIdAsync(physicianId);
        }

        public async Task<bool> UpdateAppointmentStatusAsync(int appointmentId, int status)
        {
            return await _physicianRepository.UpdateAppointmentStatusAsync(appointmentId, status);
        }

        public async Task<bool> AddOrUpdateMedicalRecordAsync(MedicalRecord medicalRecord)
        {
            return await _physicianRepository.AddOrUpdateMedicalRecordAsync(medicalRecord);
        }

        public async Task<List<Physician>> GetPhysician()
        {
            return await _physicianRepository.GetPhysician();
        }

        public Task<Physician> RegistrPhysicianAsync(Physician patient)
        {
            return _physicianRepository.RegistrPhysicianAsync(patient);
        }
    }
}
