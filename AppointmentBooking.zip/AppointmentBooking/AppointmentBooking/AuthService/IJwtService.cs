﻿namespace AppointmentBooking.AuthService
{
    public interface IJwtService
    {
        string GetJwtToken();
        void SetJwtToken(string token);
    }

    public class JwtService : IJwtService
    {
        private string _jwtToken;

        public string GetJwtToken()
        {
            return _jwtToken;
        }

        public void SetJwtToken(string token)
        {
            _jwtToken = token;
        }
    }
}
